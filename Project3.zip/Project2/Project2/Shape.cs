﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    interface Shape
    {
        bool Inside(Point point);
        Color Color(Point point);
        void SetColor(Color color);
        PointColor Intersection(Point point, Vector ray);
    }
}
